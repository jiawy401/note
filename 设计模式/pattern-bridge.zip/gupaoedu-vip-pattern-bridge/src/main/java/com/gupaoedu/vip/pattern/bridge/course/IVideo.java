package com.gupaoedu.vip.pattern.bridge.course;

/**
 * Created by Tom.
 */
public interface IVideo {
}
