package com.gupaoedu.vip.pattern.bridge.course;

/**
 * Created by Tom.
 */
public class PythonVideo implements IVideo {
}
