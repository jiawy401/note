package com.gupaoedu.vip.pattern.adapter.general.objectadapter;

/**
 * Created by Tom.
 */
public class Adaptee{

    public int specificRequest() {
        return 220;
    }
}
