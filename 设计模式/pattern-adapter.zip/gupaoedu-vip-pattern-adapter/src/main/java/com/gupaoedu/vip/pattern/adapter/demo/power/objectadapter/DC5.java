package com.gupaoedu.vip.pattern.adapter.demo.power.objectadapter;

/**
 * Created by Tom.
 */
public interface DC5 {
    int output5V();
}
