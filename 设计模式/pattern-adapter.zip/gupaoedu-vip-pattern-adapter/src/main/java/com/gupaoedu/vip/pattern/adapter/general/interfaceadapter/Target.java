package com.gupaoedu.vip.pattern.adapter.general.interfaceadapter;

/**
 * Created by Tom.
 */
public interface Target {
    int request1();
    int request2();
    int request3();
    int request4();
}
