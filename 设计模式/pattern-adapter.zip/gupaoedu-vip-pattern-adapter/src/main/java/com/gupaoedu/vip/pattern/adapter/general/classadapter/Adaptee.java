package com.gupaoedu.vip.pattern.adapter.general.classadapter;

/**
 * Created by Tom.
 */
public class Adaptee{

    public int specificRequest() {
        return 220;
    }
}
